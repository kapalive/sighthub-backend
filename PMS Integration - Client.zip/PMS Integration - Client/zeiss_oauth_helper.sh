#!/bin/bash

# ZEISS ID OAuth2 Helper Script
# Использование: ./zeiss_oauth_helper.sh [authorize|token|test-api]

ZEISS_ID_SERVER="https://id-ip-stage.zeiss.com"
CLIENT_ID="a346b369-8dd8-4fe4-a8bc-755a5192ead6"
REDIRECT_URI="https://jwt.ms"
POLICY="B2C_1A_ZeissIdNormalSignIn"

# Файл для хранения PKCE параметров
PKCE_FILE="/tmp/zeiss_pkce.json"

generate_pkce() {
    echo "=== Генерация PKCE параметров ==="
    python3 << 'PYTHON'
import secrets
import base64
import hashlib
import json

# Генерируем code_verifier
code_verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8').rstrip('=')

# Генерируем code_challenge
code_challenge = base64.urlsafe_b64encode(
    hashlib.sha256(code_verifier.encode('utf-8')).digest()
).decode('utf-8').rstrip('=')

# Генерируем state
state = base64.urlsafe_b64encode(secrets.token_bytes(16)).decode('utf-8').rstrip('=')

pkce_data = {
    "code_verifier": code_verifier,
    "code_challenge": code_challenge,
    "state": state
}

# Сохраняем в файл
with open("/tmp/zeiss_pkce.json", "w") as f:
    json.dump(pkce_data, f)

print(json.dumps(pkce_data, indent=2))
PYTHON
}

authorize() {
    if [ ! -f "$PKCE_FILE" ]; then
        generate_pkce
    fi
    
    echo ""
    echo "=== ШАГ 1: Получение Authorization Code ==="
    echo ""
    
    # Читаем PKCE параметры
    CODE_CHALLENGE=$(python3 -c "import json; print(json.load(open('$PKCE_FILE'))['code_challenge'])")
    STATE=$(python3 -c "import json; print(json.load(open('$PKCE_FILE'))['state'])")
    
    SCOPE="openid ${CLIENT_ID} offline_access"
    
    # Формируем URL
    AUTHORIZE_URL="${ZEISS_ID_SERVER}/oauth2/v2.0/authorize?p=${POLICY}&response_type=code&client_id=${CLIENT_ID}&scope=$(echo $SCOPE | sed 's/ /%20/g')&redirect_uri=$(echo $REDIRECT_URI | python3 -c "import sys, urllib.parse; print(urllib.parse.quote(sys.stdin.read().strip()))")&response_mode=query&code_challenge=${CODE_CHALLENGE}&code_challenge_method=S256&state=${STATE}"
    
    echo "1. Откройте этот URL в браузере:"
    echo ""
    echo "$AUTHORIZE_URL"
    echo ""
    echo "2. После авторизации вы будете перенаправлены на:"
    echo "   ${REDIRECT_URI}?code=<AUTHORIZATION_CODE>&state=${STATE}"
    echo ""
    echo "3. Скопируйте значение параметра 'code' из URL"
    echo ""
    echo "4. Затем выполните:"
    echo "   ./zeiss_oauth_helper.sh token <AUTHORIZATION_CODE>"
}

token() {
    if [ -z "$1" ]; then
        echo "Ошибка: нужен authorization code"
        echo "Использование: $0 token <AUTHORIZATION_CODE>"
        exit 1
    fi
    
    if [ ! -f "$PKCE_FILE" ]; then
        echo "Ошибка: PKCE параметры не найдены. Сначала выполните authorize"
        exit 1
    fi
    
    echo "=== ШАГ 2: Обмен Authorization Code на Access Token ==="
    echo ""
    
    AUTHORIZATION_CODE="$1"
    CODE_VERIFIER=$(python3 -c "import json; print(json.load(open('$PKCE_FILE'))['code_verifier'])")
    
    echo "Отправка запроса на token endpoint..."
    echo ""
    
    RESPONSE=$(curl -s -X POST "${ZEISS_ID_SERVER}/oauth2/v2.0/token?p=${POLICY}" \
      -H "Content-Type: application/x-www-form-urlencoded" \
      -d "grant_type=authorization_code" \
      -d "code=${AUTHORIZATION_CODE}" \
      -d "redirect_uri=${REDIRECT_URI}" \
      -d "code_verifier=${CODE_VERIFIER}")
    
    echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"
    
    # Сохраняем токен если успешно
    ACCESS_TOKEN=$(echo "$RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data.get('access_token', ''))" 2>/dev/null)
    if [ -n "$ACCESS_TOKEN" ]; then
        echo "$RESPONSE" > /tmp/zeiss_tokens.json
        echo ""
        echo "✅ Токен получен и сохранен в /tmp/zeiss_tokens.json"
        echo ""
        echo "Использование токена:"
        echo "  Authorization: Bearer $ACCESS_TOKEN"
    fi
}

test_api() {
    if [ ! -f "/tmp/zeiss_tokens.json" ]; then
        echo "Ошибка: токен не найден. Сначала получите токен:"
        echo "  $0 authorize"
        echo "  $0 token <CODE>"
        exit 1
    fi
    
    ACCESS_TOKEN=$(python3 -c "import json; print(json.load(open('/tmp/zeiss_tokens.json'))['access_token'])" 2>/dev/null)
    
    if [ -z "$ACCESS_TOKEN" ]; then
        echo "Ошибка: не удалось извлечь access_token"
        exit 1
    fi
    
    echo "=== Тест API запроса ==="
    echo ""
    echo "Запрос статуса заказа..."
    echo ""
    
    curl -X GET "https://api-stage.vision.zeiss.com/public/api/b2boptic/v2/orders/status?infoOut=0.3&originator=632541.211395&orderId=1800204" \
      -H "Ocp-Apim-Subscription-Key: 8d1181e5097f40e981fc802f65f03814" \
      -H "Authorization: Bearer ${ACCESS_TOKEN}" \
      -H "Content-Type: application/xml" \
      -v
}

case "$1" in
    authorize)
        authorize
        ;;
    token)
        token "$2"
        ;;
    test-api)
        test_api
        ;;
    *)
        echo "ZEISS ID OAuth2 Helper"
        echo ""
        echo "Использование: $0 [command]"
        echo ""
        echo "Команды:"
        echo "  authorize          - Генерирует PKCE и показывает URL для авторизации"
        echo "  token <code>       - Обменивает authorization code на access token"
        echo "  test-api           - Тестирует API запрос с полученным токеном"
        echo ""
        echo "Пример:"
        echo "  1. $0 authorize"
        echo "  2. Откройте URL в браузере и авторизуйтесь"
        echo "  3. Скопируйте code из redirect URL"
        echo "  4. $0 token <ваш_code>"
        echo "  5. $0 test-api"
        ;;
esac

#!/usr/bin/env python3
"""
ZEISS ID OAuth2 Authorization Code Flow with PKCE
Правильная реализация по схеме (1)-(13)

Шаги:
(1) User clicks Log In
(2) Opens Login page
(3) Authorization request with personal account
(4) Generate Code Verifier and Code Challenge (на сервере!)
(5) Authorization Request + Code Challenge
(6) Server issues Code to Browser
(7) Redirect Code to App (Redirect URI)
(8) Send Code to token endpoint + Code Verifier (server-to-server)
(9) Validate Code Verifier and Challenge
(10) Send Access Token to App
(11) Use Access Token to get Resources
(12) Verify Token
(13) Provide requested Resource
"""

import secrets
import base64
import hashlib
import urllib.parse
import json
import http.server
import socketserver
import webbrowser
import threading
import time
from urllib.parse import urlparse, parse_qs

# Конфигурация
CLIENT_ID = "a346b369-8dd8-4fe4-a8bc-755a5192ead6"
REDIRECT_URI = "http://localhost:8765/callback"
ZEISS_ID_SERVER = "https://id-ip-stage.zeiss.com"
POLICY = "B2C_1A_ZeissIdNormalSignIn"
SCOPE = f"openid {CLIENT_ID} offline_access"

# Глобальные переменные для хранения PKCE параметров (на сервере!)
code_verifier = None
code_challenge = None
state = None
authorization_code = None
access_token = None
token_data = None

# Флаг для остановки сервера
server_running = True


class OAuthCallbackHandler(http.server.SimpleHTTPRequestHandler):
    """Обработчик для получения authorization code из redirect"""
    
    def do_GET(self):
        global authorization_code, state, server_running
        
        # Парсим путь и query параметры
        parsed = urlparse(self.path)
        path = parsed.path
        
        # Обрабатываем /callback с любыми query параметрами
        if path == '/callback' or path == '/callback/':
            # Парсим query параметры
            params = parse_qs(parsed.query)
            
            code = params.get('code', [None])[0]
            returned_state = params.get('state', [None])[0]
            error = params.get('error', [None])[0]
            
            if error:
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(f"""
                <html>
                <head><title>Ошибка авторизации</title></head>
                <body>
                    <h1>❌ Ошибка авторизации</h1>
                    <p>Ошибка: {error}</p>
                    <p>Описание: {params.get('error_description', [''])[0]}</p>
                    <p>Вы можете закрыть это окно.</p>
                </body>
                </html>
                """.encode('utf-8'))
                server_running = False
                return
            
            if code and returned_state:
                # ШАГ (7): Проверяем state (защита от CSRF)
                if returned_state != state:
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(f"""
                    <html>
                    <head><title>Ошибка безопасности</title></head>
                    <body>
                        <h1>❌ Ошибка безопасности</h1>
                        <p>State не совпадает! Возможна атака CSRF.</p>
                        <p>Ожидался: {state}</p>
                        <p>Получен: {returned_state}</p>
                        <p>Вы можете закрыть это окно.</p>
                    </body>
                    </html>
                    """.encode('utf-8'))
                    server_running = False
                    return
                
                # Сохраняем authorization code
                authorization_code = code
                
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write("""
                <html>
                <head><title>Авторизация успешна</title></head>
                <body>
                    <h1>✅ Авторизация успешна!</h1>
                    <p>Authorization code получен.</p>
                    <p>Обмениваю code на access token...</p>
                    <p>Вы можете закрыть это окно.</p>
                    <script>
                        setTimeout(function() {
                            window.close();
                        }, 2000);
                    </script>
                </body>
                </html>
                """.encode('utf-8'))
                
                server_running = False
            else:
                self.send_response(400)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write("<html><body><h1>Ошибка: нет code в URL</h1></body></html>".encode('utf-8'))
        elif path == '/' or path == '':
            # Корневой путь - показываем информацию
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write("""
            <html>
            <head><title>ZEISS OAuth Callback Server</title></head>
            <body>
                <h1>ZEISS OAuth Callback Server</h1>
                <p>Сервер запущен и ожидает redirect с authorization code.</p>
                <p>Ожидаемый путь: <code>/callback</code></p>
            </body>
            </html>
            """.encode('utf-8'))
        else:
            # Для других путей возвращаем 404 с информацией
            self.send_response(404)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(f"""
            <html>
            <head><title>404 - Not Found</title></head>
            <body>
                <h1>404 - Not Found</h1>
                <p>Получен путь: <code>{self.path}</code></p>
                <p>Ожидается: <code>/callback</code></p>
                <p>Попробуйте: <a href="/callback">/callback</a></p>
            </body>
            </html>
            """.encode('utf-8'))
    
    def log_message(self, format, *args):
        # Отключаем логирование для чистоты вывода
        pass


def generate_pkce():
    """
    ШАГ (4): Generate Code Verifier and Code Challenge
    ВАЖНО: code_verifier хранится ТОЛЬКО на сервере, не передается в браузер!
    """
    global code_verifier, code_challenge, state
    
    # Генерируем code_verifier (43-128 символов, URL-safe base64)
    code_verifier = base64.urlsafe_b64encode(
        secrets.token_bytes(32)
    ).decode('utf-8').rstrip('=')
    
    # Генерируем code_challenge (SHA256 от verifier)
    code_challenge = base64.urlsafe_b64encode(
        hashlib.sha256(code_verifier.encode('utf-8')).digest()
    ).decode('utf-8').rstrip('=')
    
    # Генерируем state (защита от CSRF)
    state = base64.urlsafe_b64encode(
        secrets.token_bytes(16)
    ).decode('utf-8').rstrip('=')
    
    print(f"✅ PKCE параметры сгенерированы (на сервере):")
    print(f"   code_verifier: {code_verifier[:30]}... (хранится только на сервере)")
    print(f"   code_challenge: {code_challenge}")
    print(f"   state: {state}")


def start_callback_server():
    """Запускает локальный HTTP сервер для получения redirect"""
    global server_running
    
    PORT = 8765
    
    with socketserver.TCPServer(("", PORT), OAuthCallbackHandler) as httpd:
        print(f"✅ Локальный сервер запущен на http://localhost:{PORT}")
        print(f"   Ожидаю redirect с authorization code...")
        
        # Запускаем сервер в отдельном потоке
        server_thread = threading.Thread(target=httpd.serve_forever)
        server_thread.daemon = True
        server_thread.start()
        
        # Ждем пока сервер не получит code или не будет остановлен
        while server_running:
            time.sleep(0.1)
        
        httpd.shutdown()
        print("✅ Сервер остановлен")


def open_authorization_url():
    """
    ШАГ (5): Authorization Request + Code Challenge
    Открываем браузер с URL авторизации
    """
    params = {
        "p": POLICY,
        "response_type": "code",
        "client_id": CLIENT_ID,
        "scope": SCOPE,
        "redirect_uri": REDIRECT_URI,
        "response_mode": "query",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state
    }
    
    auth_url = f"{ZEISS_ID_SERVER}/oauth2/v2.0/authorize?" + urllib.parse.urlencode(params)
    
    print(f"\n✅ Открываю браузер с URL авторизации...")
    print(f"   URL: {auth_url[:100]}...")
    
    webbrowser.open(auth_url)
    
    print(f"\n📋 Инструкция:")
    print(f"   1. В браузере войдите в ZEISS ID")
    print(f"   2. После авторизации произойдет redirect на localhost:8765/callback")
    print(f"   3. Authorization code будет получен автоматически")


def exchange_code_for_token():
    """
    ШАГ (8): Send Code to token endpoint + Code Verifier
    Server-to-server запрос (code_verifier НЕ передается через браузер!)
    """
    global access_token, token_data
    
    if not authorization_code:
        print("❌ Ошибка: нет authorization code")
        return False
    
    print(f"\n✅ Обмениваю authorization code на access token...")
    print(f"   Использую code_verifier (хранится на сервере): {code_verifier[:30]}...")
    
    token_url = f"{ZEISS_ID_SERVER}/oauth2/v2.0/token?p={POLICY}"
    
    data = {
        "grant_type": "authorization_code",
        "code": authorization_code,
        "redirect_uri": REDIRECT_URI,
        "code_verifier": code_verifier  # Отправляем только на сервере!
    }
    
    import urllib.request
    import urllib.error
    
    try:
        # Формируем POST запрос
        post_data = urllib.parse.urlencode(data).encode('utf-8')
        req = urllib.request.Request(token_url, data=post_data)
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        
        with urllib.request.urlopen(req) as response:
            response_data = response.read().decode('utf-8')
            token_data = json.loads(response_data)
            access_token = token_data.get('access_token')
            
            print(f"✅ Access Token получен!")
            print(f"   Token: {access_token[:50]}...")
            print(f"   Expires in: {token_data.get('expires_in')} секунд")
            
            # Сохраняем токены в файл
            with open('/tmp/zeiss_tokens.json', 'w') as f:
                json.dump(token_data, f, indent=2)
            print(f"   Токены сохранены в /tmp/zeiss_tokens.json")
            
            return True
            
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"❌ Ошибка при получении токена:")
        print(f"   Status: {e.code}")
        print(f"   Response: {error_body}")
        return False
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def test_api():
    """
    ШАГ (11): Use Access Token to get Resources
    Тестируем API запрос с access token
    """
    if not access_token:
        print("❌ Ошибка: нет access token")
        return
    
    print(f"\n✅ Тестирую API запрос с access token...")
    
    api_url = "https://api-stage.vision.zeiss.com/public/api/b2boptic/v2/orders/status"
    params = {
        "infoOut": "0.3",
        "originator": "632541.211395",
        "orderId": "1800204"
    }
    
    headers = {
        "Ocp-Apim-Subscription-Key": "8d1181e5097f40e981fc802f65f03814",
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/xml"
    }
    
    import urllib.request
    import urllib.error
    
    try:
        # Формируем URL с параметрами
        url_with_params = api_url + '?' + urllib.parse.urlencode(params)
        req = urllib.request.Request(url_with_params)
        for key, value in headers.items():
            req.add_header(key, value)
        
        with urllib.request.urlopen(req) as response:
            response_data = response.read().decode('utf-8')
            print(f"   Status: {response.getcode()}")
            print(f"   Response:\n{response_data[:500]}...")
            print(f"✅ API запрос успешен!")
            
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"   Status: {e.code}")
        print(f"   Response:\n{error_body[:500]}...")
        print(f"⚠️  API вернул ошибку (возможно проблема с customer number)")
    except Exception as e:
        print(f"❌ Ошибка: {e}")


def main():
    """
    Главная функция - выполняет весь OAuth2 flow
    """
    print("=" * 60)
    print("ZEISS ID OAuth2 Authorization Code Flow with PKCE")
    print("=" * 60)
    
    # ШАГ (4): Генерируем PKCE на сервере
    print("\n[ШАГ 4] Генерация PKCE параметров...")
    generate_pkce()
    
    # Запускаем локальный сервер для получения redirect
    print("\n[ШАГ 2-3] Запуск локального сервера для получения redirect...")
    server_thread = threading.Thread(target=start_callback_server)
    server_thread.daemon = True
    server_thread.start()
    
    time.sleep(1)  # Даем серверу время запуститься
    
    # ШАГ (5): Открываем браузер с URL авторизации
    print("\n[ШАГ 5] Открытие браузера с authorization request...")
    open_authorization_url()
    
    # Ждем получения authorization code
    print("\n[ШАГ 6-7] Ожидание authorization code...")
    timeout = 300  # 5 минут
    start_time = time.time()
    
    while not authorization_code and (time.time() - start_time) < timeout:
        time.sleep(0.5)
    
    if not authorization_code:
        print("❌ Timeout: authorization code не получен")
        return
    
    print(f"✅ Authorization code получен: {authorization_code[:50]}...")
    
    # ШАГ (8-10): Обмениваем code на token
    print("\n[ШАГ 8-10] Обмен code на access token...")
    if not exchange_code_for_token():
        return
    
    # ШАГ (11-13): Тестируем API
    print("\n[ШАГ 11-13] Тестирование API...")
    test_api()
    
    print("\n" + "=" * 60)
    print("✅ OAuth2 Flow завершен успешно!")
    print("=" * 60)
    print(f"\nAccess Token сохранен в /tmp/zeiss_tokens.json")
    print(f"Используйте его для API запросов:")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Прервано пользователем")
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
